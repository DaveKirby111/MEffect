<?php

return [
	'title' => __( 'Admin User', 'it-l10n-ithemes-security-pro' ),
];
