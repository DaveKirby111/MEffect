<?php
require_once( __DIR__ . '/class-itsec-hibp.php' );

return 'ITSEC_HIBP';
