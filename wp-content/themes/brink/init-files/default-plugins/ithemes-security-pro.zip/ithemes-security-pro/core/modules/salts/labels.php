<?php

return [
	'title' => __( 'WordPress Salts', 'it-l10n-ithemes-security-pro' ),
];
