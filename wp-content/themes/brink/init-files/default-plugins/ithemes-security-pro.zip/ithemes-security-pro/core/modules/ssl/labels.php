<?php

return [
	'title' => __( 'SSL', 'it-l10n-ithemes-security-pro' ),
];
