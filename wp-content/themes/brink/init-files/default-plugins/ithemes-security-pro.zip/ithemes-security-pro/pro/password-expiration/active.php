<?php

require_once( __DIR__ . '/class-itsec-password-expiration.php' );

return 'ITSEC_Password_Expiration';
