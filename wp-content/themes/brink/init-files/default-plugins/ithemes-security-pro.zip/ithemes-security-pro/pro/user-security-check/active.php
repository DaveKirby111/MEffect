<?php

require_once( 'class-itsec-user-security-check.php' );
$itsec_user_security_check = new ITSEC_User_Security_Check();
$itsec_user_security_check->run();
