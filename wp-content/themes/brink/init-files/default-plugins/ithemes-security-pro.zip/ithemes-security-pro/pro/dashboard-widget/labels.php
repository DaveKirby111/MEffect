<?php

return [
	'title' => __( 'Dashboard Widget', 'it-l10n-ithemes-security-pro' ),
];
