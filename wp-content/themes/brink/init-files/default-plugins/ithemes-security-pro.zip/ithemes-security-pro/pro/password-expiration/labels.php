<?php

return [
	'title' => __( 'Password Expiration', 'it-l10n-ithemes-security-pro' ),
];
