<?php

return [
	'title' => __( 'Recaptcha', 'it-l10n-ithemes-security-pro' ),
];
