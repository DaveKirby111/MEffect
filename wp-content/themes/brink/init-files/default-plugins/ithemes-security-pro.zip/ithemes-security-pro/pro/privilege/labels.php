<?php

return [
	'title' => __( 'Privilege Escalation', 'it-l10n-ithemes-security-pro' ),
];
